package be.pxl.ja.opgave1;

public class TeamFullException extends Exception {
    public TeamFullException(String msg) {
        super(msg);
    }
}
