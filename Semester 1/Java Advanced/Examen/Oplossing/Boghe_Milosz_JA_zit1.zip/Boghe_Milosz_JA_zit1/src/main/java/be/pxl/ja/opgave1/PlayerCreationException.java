package be.pxl.ja.opgave1;

public class PlayerCreationException extends Exception {
    public PlayerCreationException(String msg) {
        super(msg);
    }
}
