package be.pxl.ja.opgave1;

public class PositionFullException extends Exception {
    public PositionFullException(String msg) {
        super(msg);
    }
}
