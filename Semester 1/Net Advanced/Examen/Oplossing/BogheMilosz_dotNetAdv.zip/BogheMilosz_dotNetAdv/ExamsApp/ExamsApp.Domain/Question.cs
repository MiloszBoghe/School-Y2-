﻿using System.Collections.Generic;

namespace ExamsApp.Domain
{
    public class Question
    {
        //TODO: define properties
        public int Id { get; set; }
        public string Text { get; set; }
        public bool CanHaveMultipleCorrectAnswers { get; set; }

        public ICollection<Answer> Answers { get; set; }
    }
}