﻿
namespace ExamsApp.Domain
{
    public class Answer
    {
        //TODO: define properties
        public int QuestionId { get; set; }
        public int Number { get; set; }
        public string Text { get; set; }
        public bool IsCorrect { get; set; }

        public Question Question { get; set; }
    }
}
