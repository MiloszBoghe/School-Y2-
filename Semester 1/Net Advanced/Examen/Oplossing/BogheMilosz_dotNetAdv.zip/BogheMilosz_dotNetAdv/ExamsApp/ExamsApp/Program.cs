﻿using ExamsApp.Data;
using ExamsApp.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ExamsApp
{
    class Program
    {
        private static readonly ExamsContext _context = new ExamsContext();
        static void Main(string[] args)
        {
            GetQuestionsAndAnswers();
            AddAnswerToFirstExistingQuestion();
            
            Console.WriteLine();
            Console.WriteLine("Press any key to quit...");
            Console.ReadKey(true);
        }

        private static void GetQuestionsAndAnswers()
        {
            //DONE: use the _context to retrieve all questions with their answers.
            //DONE: uncomment the 'PrintQuestion' method (below) and use it to print each question and answer in the console
            List<Question> questions = _context.Questions.Include(q=>q.Answers).ToList();
            foreach(Question q in questions)
            {
                PrintQuestion(q);
            }

        }

        private static void AddAnswerToFirstExistingQuestion()
        {
            //DONE: add a new (incorrect) answer to the first question
            //The number of the new question = the highest number of the other answers of the question + 1
            //You can choose the text of the answer freely
            _context.Questions.First().Answers.Add(new Answer() { QuestionId = 1, Number = 6, Text = "Alle bovenstaande", IsCorrect = false }) ;
        }

        private static void PrintQuestion(Question question)
        {
            Console.Write(question.Id + ". ");
            Console.WriteLine(question.Text);
            foreach (var answer in question.Answers)
            {
                Console.Write("\t");
                if (answer.IsCorrect)
                {
                    Console.Write("x ");
                }
                Console.WriteLine(answer.Text);
            }
        }
    }
}
