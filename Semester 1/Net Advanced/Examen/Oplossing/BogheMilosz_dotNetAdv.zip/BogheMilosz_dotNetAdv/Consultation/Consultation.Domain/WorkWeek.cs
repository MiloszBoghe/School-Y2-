﻿using System;

namespace Consultation.Domain
{
    public class WorkWeek
    {
        public DateTime Monday { get; }

        public DateTime Friday { get; }

        private WorkWeek(DateTime monday, DateTime friday)
        {
            Monday = monday;
            Friday = friday;
        }

        public static WorkWeek GetWorkWeekOf(DateTime date)
        {
            var monday = date.AddDays(-(int)date.DayOfWeek + 1);
            var friday = monday.AddDays(4);
            return new WorkWeek(monday, friday);
        }
        
        public override string ToString()
        {
            return $"{Monday:dd/MM/yyyy} - {Friday:dd/MM/yyyy}";
        }
    }
}