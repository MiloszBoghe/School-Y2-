﻿using System;

namespace Consultation.Domain
{
    public class Patient
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string FirstName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public char Sex { get; set; }
        public string Address1 { get; set; }
        public int Zip { get; set; }
        public string City { get; set; }
    }
}
