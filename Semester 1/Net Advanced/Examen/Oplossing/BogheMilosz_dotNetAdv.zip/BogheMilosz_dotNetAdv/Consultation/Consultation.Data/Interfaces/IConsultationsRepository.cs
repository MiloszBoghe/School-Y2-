﻿using Consultation.Domain;
using System.Collections.Generic;

namespace Consultation.Data.Interfaces
{
    public interface IConsultationsRepository
    {
        List<Consult> GetConsultationsOfDoctor(int doctorId);
        bool AddConsultation(Consult consultation);
    }
}
;