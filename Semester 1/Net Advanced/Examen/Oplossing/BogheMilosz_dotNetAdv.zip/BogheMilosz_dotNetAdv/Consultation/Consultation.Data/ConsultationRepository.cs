﻿using Consultation.Data.Interfaces;
using Consultation.Domain;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;

namespace Consultation.Data
{
    public class ConsultationsRepository : IConsultationsRepository
    {
        IConnectionFactory _connectionFactory;
        public ConsultationsRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public bool AddConsultation(Consult consultation)
        {
            //DONE: use ADO.NET to save a new consultation in the database.
            //Use the connectionFactory that is injected into the constructor to create a connection
            //Avoid SQL Injection attacks
            //Handle null values correctly
            //Return true if the consultation is actually saved, otherwise return false
            SqlTransaction sqlTransaction = null;
            SqlConnection connection = _connectionFactory.CreateSqlConnection();

            try
            {
                connection.Open();
                sqlTransaction = connection.BeginTransaction();
                sqlTransaction.Save("start");
                SqlCommand insertConsultationCommand = new SqlCommand();
                insertConsultationCommand.Connection = connection;
                insertConsultationCommand.Transaction = sqlTransaction;

                //Parameters to avoid SQL injection attacks:
                insertConsultationCommand.Parameters.AddWithValue("@dId", consultation.DoctorId);
                insertConsultationCommand.Parameters.AddWithValue("@pId", consultation.PatientId);
                insertConsultationCommand.Parameters.AddWithValue("@Date", consultation.ConsultationDate);
                insertConsultationCommand.Parameters.AddWithValue("@Duration", consultation.Duration);
                insertConsultationCommand.Parameters.AddWithValue("@Comment", consultation.Comment);

                string insertQuery = "Insert into Consultations(DoctorId, PatientId, ConsultationDate, Duration, Comment) values(@dId, @pId, @Date, @Duration, @Comment)";
                insertConsultationCommand.CommandText = insertQuery;
                insertConsultationCommand.ExecuteNonQuery();

                //if nothing went wrong:
                MessageBox.Show("Consultatie toegevoegd.");
                sqlTransaction.Commit();
                

            }
            catch (Exception)
            {
                //if something went wrong, rollback, close connection and stop:
                Console.WriteLine("Something went wrong");
                sqlTransaction.Rollback("start");
                connection.Close();
                return false;
            }
            finally
            {
                connection.Close();
            }
            return true;

        }

        public List<Consult> GetConsultationsOfDoctor(int doctorId)
        {
            //TODO: use ADO.NET to get all the booked consultations of a doctor
            //Use the connectionFactory that is injected into the constructor to create a connection
            //Use parameters to pass the input data
            //This method should be as efficient as possible (there could be many doctors in the database)
            //Handle null values correctly

            SqlDataReader reader = null;
            List<Consult> consultationList = new List<Consult>();
            SqlConnection connection = _connectionFactory.CreateSqlConnection();

            string selectStatement =
                "SELECT * " +
                "FROM Consultations " +
                "WHERE DoctorId = @dId";

            //command maken en parameters instellen:
            SqlCommand selectCommand = new SqlCommand();
            selectCommand.Connection = connection;
            selectCommand.Parameters.AddWithValue("@dId", doctorId);
            selectCommand.CommandText = selectStatement;
            try
            {
                connection.Open();
                reader = selectCommand.ExecuteReader();

                while (reader.Read())
                {
                    Consult consult = new Consult()
                    {
                        //ik ga er van uit dat ID en Date geen null kunnen zijn
                        DoctorId = doctorId,
                        PatientId = Convert.ToInt32(reader["PatientId"]),
                        ConsultationDate = Convert.ToDateTime(reader["ConsultationDate"]),
                        Duration = reader["Duration"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Duration"]),
                        Comment = reader["Comment"] == DBNull.Value ? "" : Convert.ToString(reader["Comment"])
                    };
                    consultationList.Add(consult);
                }
            }
            catch (Exception)
            {
                Console.WriteLine("something went wrong when getting consultations");
            }

            finally
            {
                reader?.Close();
                connection?.Close();
            }
            return consultationList;

        }
    }
}
