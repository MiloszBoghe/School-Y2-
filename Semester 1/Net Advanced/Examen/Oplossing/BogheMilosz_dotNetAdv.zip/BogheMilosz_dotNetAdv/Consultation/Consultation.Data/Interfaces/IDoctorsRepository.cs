﻿using Consultation.Domain;
using System.Collections.Generic;

namespace Consultation.Data.Interfaces
{
    public interface IDoctorsRepository
    {
        IList<Doctor> GetAllDoctors();
    }
}
