﻿using Consultation.Data.Interfaces;
using Consultation.Domain;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Consultation.Data
{
    public class PatientsRepository : IPatientsRepository
    {
        IConnectionFactory _connectionFactory;
        public PatientsRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public IList<Patient> GetAllPatients()
        {
            SqlDataReader reader = null;
            IList<Patient> patientList = new List<Patient>();
            SqlConnection connection = _connectionFactory.CreateSqlConnection();

            string selectStatement =
                "SELECT * " +
                "FROM Patients";

            SqlCommand command = new SqlCommand(selectStatement, connection);
            try
            {
                connection.Open();
                reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Patient patient = new Patient()
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Name = Convert.ToString(reader["Name"]),
                        FirstName = Convert.ToString(reader["FirstName"]),
                        Sex = Convert.ToChar(reader["Sex"]),
                        DateOfBirth = Convert.ToDateTime(reader["DateOfBirth"]),
                        Address1 = Convert.ToString(reader["Address1"]),
                        Zip = Convert.ToInt32(reader["Zip"]),
                        City = Convert.ToString(reader["City"])
                        
                    };
                    patientList.Add(patient);
                }
            }
            catch (Exception)
            {
                Console.WriteLine("something went wrong");
            }

            finally
            {
                reader?.Close();
                connection?.Close();
            }

            return patientList;

        }
    }
}
