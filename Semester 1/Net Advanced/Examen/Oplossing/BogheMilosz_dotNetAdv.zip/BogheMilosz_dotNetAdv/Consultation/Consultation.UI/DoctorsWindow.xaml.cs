﻿using Consultation.Business.Interfaces;
using Consultation.Data.Interfaces;
using Consultation.Domain;
using System.Windows;

namespace Consultation.UI
{
    public partial class DoctorsWindow : Window
    {
        IGenerateWeeksService _generateWeeksService;
        IUnitOfWork _unitOfWork;
        public DoctorsWindow(IUnitOfWork unitOfWork, IGenerateWeeksService generateWeeksService)
        {
            //DONE: use the DoctorsRepository in the unitOfWork to get all the doctors
            //Show the retrieved doctors in the ListView using data binding
            InitializeComponent();
            _generateWeeksService = generateWeeksService;
            _unitOfWork = unitOfWork;
            DoctorsListView.ItemsSource = unitOfWork.DoctorsRepository.GetAllDoctors();

        }

        private void ChooseDoctorButton_Click(object sender, RoutedEventArgs e)
        {
            //DONE: show the a message box with the text 'Gelieve eerst een arts te selecteren' if there isn't any doctor selected
            //DONE: show a new instance of 'DatePickerWindow' as a dialog. The selected doctor should be passed to this window
            if (DoctorsListView.SelectedItem == null)
            {
                MessageBox.Show("Gelieve eerst een arts te selecteren.");
            }
            else
            {
                Doctor doctor = (Doctor)DoctorsListView.SelectedItem;
                Window datePickerWindow = new DatePickerWindow(doctor, _generateWeeksService, _unitOfWork);
                datePickerWindow.Show();
            }

        }
    }
    //DONE: also check the TODO's in DatePickerWindow.xaml.cs, ChooseConsultationMomentWindow.xaml.cs, AddConsultationWindow.xaml.cs
}
