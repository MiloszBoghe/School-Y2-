﻿using Consultation.Data.Interfaces;
using Consultation.Domain;
using System;
using System.Windows;

namespace Consultation.UI
{
    public partial class AddConsultationWindow : Window
    {
        IUnitOfWork _unitOfWork;
        Consult _consult;
        Doctor _doctor;
        DateTime _date;
        public AddConsultationWindow(DateTime dateTime, Doctor doctor, IUnitOfWork unitOfWork)
        {
            //DONE: use the PatientsRepository in the unitOfWork to get all the patients
            //Show the 'Name' property of the retrieved patients in the ListBox using data binding
            //Also use data binding to set the 'PatientId' property as the SelectedValue of the ListBox when a patient is selected

            //DONE: construct a 'Consult' instance and use two-way binding to set the 'PatientId' and 'Comment' properties
            //The 'Duration' property can be set hardcoded to 60 (minutes).

            InitializeComponent();
            _unitOfWork = unitOfWork;
            _doctor = doctor;
            _date = dateTime;
            PatientsListBox.ItemsSource = unitOfWork.PatientsRepository.GetAllPatients();
        }

        private void AddConsultationButton_Click(object sender, RoutedEventArgs e)
        {
            //DONE: show the a message box with the text 'Gelieve een patient te selecteren' if there isn't any patient selected
            //DONE: use the 'ConsultationsRepository' in the unitOfWork to add (save) the consultation
            //Show a message box with the text 'Consultatie toegevoegd'
            _consult.Duration = 60;
            _consult.PatientId = ((Patient)PatientsListBox.SelectedItem).Id;
            _consult.DoctorId = _doctor.Id;
            _consult.ConsultationDate = _date;

            if (PatientsListBox.SelectedItem == null)
            {
                MessageBox.Show("Gelieve eerst een patient te selecteren.");
            }
            else
            {
                _unitOfWork.ConsultationsRepository.AddConsultation(_consult);
            }

        }

        private void PatientsListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            _consult = new Consult();
            ConsulationCommentTextBox.DataContext = _consult;
        }
    }
    //DONE: also check the TODO's in DoctorsWindow.xaml.cs, DatePickerWindow.xaml.cs, ChooseConsultationMomentWindow.xaml.cs
}
