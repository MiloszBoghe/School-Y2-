﻿using Consultation.Business.Interfaces;
using Consultation.Data.Interfaces;
using Consultation.Domain;
using System;
using System.Windows;

namespace Consultation.UI
{
    public partial class DatePickerWindow : Window
    {
        Doctor _doctor;
        IUnitOfWork _unitOfWork;

        public DatePickerWindow(Doctor doctor, IGenerateWeeksService generateWeeksService, IUnitOfWork unitOfWork)
        {
            // DONE: use the GenerateWeeksService to retrieve the next 5 workweeks (starting from today)
            //Show the retrieved doctors in the DatesListBox (Tip that could save you some work: the WorkWeek class overrides the 'ToString' method)
            InitializeComponent();
            DatesListBox.ItemsSource = generateWeeksService.GenerateWeeks(DateTime.Now, 5);
            _doctor = doctor;
            _unitOfWork = unitOfWork;

        }

        private void ChooseWeek_Click(object sender, RoutedEventArgs e)
        {
            //DONE: show the a message box with the text 'Gelieve eerst een week te selecteren' if there isn't any work week selected
            //DONE show a new instance of 'ChooseConsultationMomentWindow' as a dialog. The monday of the selected work week should be passed to this window
            if (DatesListBox.SelectedItem == null)
            {
                MessageBox.Show("Gelieve eerst een week te selecteren");
            }
            else
            {
                DateTime startdate = ((WorkWeek)DatesListBox.SelectedItem).Monday;
                Window chooseConsultationMomentWindow = new ChooseConsultationMomentWindow(startdate, _doctor, _unitOfWork);
                chooseConsultationMomentWindow.Show();
            }
        }
    }
    //DONE: also check the TODO's in DoctorsWindow.xaml.cs, ChooseConsultationMomentWindow.xaml.cs, AddConsultationWindow.xaml.cs
}
