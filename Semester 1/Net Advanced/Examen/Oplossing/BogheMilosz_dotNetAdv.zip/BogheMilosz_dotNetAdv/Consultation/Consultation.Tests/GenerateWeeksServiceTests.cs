﻿using Consultation.Business;
using NUnit.Framework;
using System;

namespace Consultation.Tests
{
    //TODO: make sure the test methods will be recognized by the test runner.
    public class GenerateWeeksServiceTests
    {
        private readonly Random _random;
        private GenerateWeeksService _generateWeeksService;
        public GenerateWeeksServiceTests()
        {
            _random = new Random();
        }

        [SetUp]
        public void SetUp()
        {
             _generateWeeksService = new GenerateWeeksService();
        }
        public void ShouldThrowExceptionWhenStartDateIsBeforeToday()
        {
            //TODO: write a test that checks if an InvalidDateException is thrown when the startDate parameter is not in the future.
            //use the _random field to randomly generate a startDate in the past (DateTime has an 'AddDays' method). Do not go more than 50 days in the past.
            //avoid code duplication (each test will create a 'GenerateWeeksService' instance
           
            
            
            //Assert.Throws<InvalidDateException>(() => ));


        }

        public void ShouldGenerateCorrectAmountOfWeeks()
        {
            //TODO: write a test that checks if the correct amount of WorkWeeks are returned.
            //use the _random field to randomly generate a number of weeks (between 1 and 52)
            //avoid code duplication (each test will create a 'GenerateWeeksService' instance

            throw new NotImplementedException();
        }
    }
}
