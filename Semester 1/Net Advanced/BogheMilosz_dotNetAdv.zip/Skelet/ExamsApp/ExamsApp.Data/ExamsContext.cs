﻿
using ExamsApp.Domain;
using Microsoft.EntityFrameworkCore;

namespace ExamsApp.Data
{
    public class ExamsContext : DbContext
    {
        //DONE: complete this class using your knowledge of Entity Framework so that you can create the desired database
        public DbSet<Question> Questions { get; set; }
        public DbSet<Answer> Answers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ExamsDb;Integrated Security=True";
            optionsBuilder.UseSqlServer(connectionString);
        }


        //DONE: configure seeding so that the database is filled with the desired data when it is created/migrated

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Answer>().HasKey("QuestionId", "Number");
            modelBuilder.Entity<Question>().HasKey(q => q.Id);
            modelBuilder.Entity<Question>().Property(q => q.Text).HasMaxLength(200);
            modelBuilder.Entity<Question>().HasData(new Question() {Id=1, Text = "Welke tekst verschijnt er in het volgend berichtvenster? MessageBox.Show(\"2\"+\"2\"+4+4);", CanHaveMultipleCorrectAnswers = false });
            modelBuilder.Entity<Question>().HasData(new Question() {Id=2, Text = "Je kan het keyword \'override\' bij een methode van de subklasse schrijven als deze methode in de superklasse ", CanHaveMultipleCorrectAnswers = true }); ;
            modelBuilder.Entity<Answer>().HasData(new Answer() { QuestionId = 1, Number = 1, Text = "228", IsCorrect = false });
            modelBuilder.Entity<Answer>().HasData(new Answer() { QuestionId = 1, Number = 2, Text = "2244", IsCorrect = true });
            modelBuilder.Entity<Answer>().HasData(new Answer() { QuestionId = 1, Number = 3, Text = "12", IsCorrect = false });
            modelBuilder.Entity<Answer>().HasData(new Answer() { QuestionId = 1, Number = 4, Text = "30", IsCorrect = false });
            modelBuilder.Entity<Answer>().HasData(new Answer() { QuestionId = 1, Number = 5, Text = "Geen van bovenstaande", IsCorrect = false });
            modelBuilder.Entity<Answer>().HasData(new Answer() { QuestionId = 2, Number = 1, Text = "virtual", IsCorrect = true });
            modelBuilder.Entity<Answer>().HasData(new Answer() { QuestionId = 2, Number = 2, Text = "override", IsCorrect = true });
            modelBuilder.Entity<Answer>().HasData(new Answer() { QuestionId = 2, Number = 3, Text = "abstract", IsCorrect = true });
            modelBuilder.Entity<Answer>().HasData(new Answer() { QuestionId = 2, Number = 4, Text = "public", IsCorrect = false });


        }


    }
}
