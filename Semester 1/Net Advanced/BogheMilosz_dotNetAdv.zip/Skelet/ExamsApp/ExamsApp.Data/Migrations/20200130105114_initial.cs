﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ExamsApp.Data.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Questions",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Text = table.Column<string>(maxLength: 200, nullable: true),
                    CanHaveMultipleCorrectAnswers = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Questions", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Answers",
                columns: table => new
                {
                    QuestionId = table.Column<int>(nullable: false),
                    Number = table.Column<int>(nullable: false),
                    Text = table.Column<string>(nullable: true),
                    IsCorrect = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Answers", x => new { x.QuestionId, x.Number });
                    table.ForeignKey(
                        name: "FK_Answers_Questions_QuestionId",
                        column: x => x.QuestionId,
                        principalTable: "Questions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Questions",
                columns: new[] { "Id", "CanHaveMultipleCorrectAnswers", "Text" },
                values: new object[] { 1, false, "Welke tekst verschijnt er in het volgend berichtvenster? MessageBox.Show(\"2\"+\"2\"+4+4);" });

            migrationBuilder.InsertData(
                table: "Questions",
                columns: new[] { "Id", "CanHaveMultipleCorrectAnswers", "Text" },
                values: new object[] { 2, true, "Je kan het keyword 'override' bij een methode van de subklasse schrijven als deze methode in de superklasse " });

            migrationBuilder.InsertData(
                table: "Answers",
                columns: new[] { "QuestionId", "Number", "IsCorrect", "Text" },
                values: new object[,]
                {
                    { 1, 1, false, "228" },
                    { 1, 2, true, "2244" },
                    { 1, 3, false, "12" },
                    { 1, 4, false, "30" },
                    { 1, 5, false, "Geen van bovenstaande" },
                    { 2, 1, true, "virtual" },
                    { 2, 2, true, "override" },
                    { 2, 3, true, "abstract" },
                    { 2, 4, false, "public" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Answers");

            migrationBuilder.DropTable(
                name: "Questions");
        }
    }
}
