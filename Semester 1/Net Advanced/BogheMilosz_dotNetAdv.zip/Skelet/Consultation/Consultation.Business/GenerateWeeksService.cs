﻿using Consultation.Business.Interfaces;
using System;
using System.Collections.Generic;
using Consultation.Domain;

namespace Consultation.Business
{
    public class GenerateWeeksService : IGenerateWeeksService
    {
        /// <summary>
        /// Gets a list of work weeks
        /// </summary>
        /// <param name="startDate">A date in the future. The first work week in the returned list will contain this date.</param>
        /// <param name="numberOfWeeks">The number of weeks to generate.</param>
        /// <returns>A list of sequential workweeks starting from the week that contains the startDate.</returns>
        /// <exception cref="InvalidDateException">Thrown when the startDate is not in the future.</exception>
        public IList<WorkWeek> GenerateWeeks(DateTime startDate, int numberOfWeeks)
        {
            //TODO: Inspect the XML comments of this method, the WorkWeek class and the unit tests to figure out how to implement this method
            IList<WorkWeek> workWeeks = new List<WorkWeek>();
            workWeeks.Add(WorkWeek.GetWorkWeekOf(startDate));
            for(int i = 1; i < numberOfWeeks; i++)
            {
                startDate = startDate.AddDays(7);
                WorkWeek workWeek = WorkWeek.GetWorkWeekOf(startDate);
                workWeeks.Add(workWeek);
            }
            return workWeeks;
        }
    }
}
