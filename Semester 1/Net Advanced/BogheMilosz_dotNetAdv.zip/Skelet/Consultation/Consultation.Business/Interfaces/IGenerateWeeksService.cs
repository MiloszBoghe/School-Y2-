﻿using System;
using System.Collections.Generic;
using Consultation.Domain;

namespace Consultation.Business.Interfaces
{
    public interface IGenerateWeeksService
    {
        IList<WorkWeek> GenerateWeeks(DateTime startDate, int numberOfWeeks);
    }
}
