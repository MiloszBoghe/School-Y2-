﻿using System;

namespace Consultation.Business
{
    public class InvalidDateException: Exception 
    {
        public InvalidDateException(string message) : base(message) { }
    }
}
