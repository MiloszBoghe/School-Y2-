﻿using Consultation.Business;
using Consultation.Data;
using Consultation.Data.Interfaces;
using System.Windows;

namespace Consultation.UI
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            var connectionFactory = new ConnectionFactory();
            var unitOfWork = new UnitOfWork(connectionFactory);
            var weeksService = new GenerateWeeksService();
            var doctorsWindow = new DoctorsWindow(unitOfWork, weeksService);
            doctorsWindow.Show();
        }
    }
}
