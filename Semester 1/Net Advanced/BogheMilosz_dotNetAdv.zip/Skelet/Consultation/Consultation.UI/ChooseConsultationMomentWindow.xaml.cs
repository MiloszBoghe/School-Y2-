﻿using Consultation.Data.Interfaces;
using Consultation.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Consultation.UI
{
    //TODO: In XAML manipulate the Grid column widths and row heights so that:
    //  * The first column has half the width of the other columns
    //  * The first row adjusts its height to its content while the other rows divide the remaining space evenly
    public partial class ChooseConsultationMomentWindow : Window
    {
        //!!! Do NOT change any code in this codebehind file. You should only edit the xaml code of this window !!!!
        private readonly int _startHour;
        private readonly DateTime _startDate;
        private readonly Doctor _doctor;
        private readonly IUnitOfWork _unitOfWork;

        public ChooseConsultationMomentWindow(DateTime startDate, Doctor doctor, IUnitOfWork unitOfWork)
        {
            InitializeComponent();
            _startHour = 9;
            _doctor = doctor;
            _unitOfWork = unitOfWork;
            _startDate = startDate.Date;

            InitializeConsultationGrid(startDate);
        }

        private void InitializeConsultationGrid(DateTime startDate)
        {
            InitializeConsultationHoursColumn();

            List<Consult> consultationsOfDoctor = _unitOfWork.ConsultationsRepository.GetConsultationsOfDoctor(_doctor.Id);

            for (int dayOfWeek = 1; dayOfWeek <= 5; ++dayOfWeek)
            {
                InitializeColumnHeader(startDate, dayOfWeek);
                InitializeConsultationMomentCellsForDayOfWeek(dayOfWeek, consultationsOfDoctor);
            }
        }

        private void InitializeConsultationMomentCellsForDayOfWeek(int dayOfWeek, IList<Consult> consultationsOfDoctor)
        {
            List<string> consultationStartHours =
                _unitOfWork.ConsultationHoursRepository.GetConsultationStartHoursForDoctorOnWeekDay(_doctor.Id, dayOfWeek);

            if (!consultationStartHours.Any()) return;

            for (int rowIndex = 1; rowIndex < consulationMomentsGrid.RowDefinitions.Count; rowIndex++)
            {
                var hour = _startHour + rowIndex - 1;
                if (consultationStartHours.Contains(GetHourString(hour)))
                {
                    SolidColorBrush brush = new SolidColorBrush(Colors.LightGray);
                  
                    Button button = new Button
                    {
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center,
                        Content = "",
                        Width = 144,
                        Height = 55,
                        Background = brush
                    };

                    Grid.SetRow(button, rowIndex);
                    Grid.SetColumn(button, dayOfWeek);
                    
                    DateTime consultationDate = GetConsultationDateTimeForCell(rowIndex, dayOfWeek);

                    var isAlreadyBooked = consultationsOfDoctor.Any(c => c.ConsultationDate == consultationDate);

                    if (isAlreadyBooked)
                    {
                        brush.Color = Colors.Red;
                    }
                    else
                    {
                        button.Content = "Afspraak maken";
                        button.Click += AddConsultationButton_Click;
                    }

                    consulationMomentsGrid.Children.Add(button);
                }
            }
        }

        private void InitializeColumnHeader(DateTime date, int columnIndex)
        {
            TextBlock dayTextBlock = new TextBlock
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Padding = new Thickness(0,4,0,4),
                Text = $"{date:dd/MM/yyyy}"
            };
            Grid.SetRow(dayTextBlock, 0);
            Grid.SetColumn(dayTextBlock, columnIndex);
            consulationMomentsGrid.Children.Add(dayTextBlock);
        }

        private void InitializeConsultationHoursColumn()
        {
            var hour = _startHour;
            for (int i = 1; i < 9; ++i)
            {
                TextBlock hourTextBlock = new TextBlock
                {
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                    Text = GetHourString(hour)
                };

                Grid.SetRow(hourTextBlock, i);
                Grid.SetColumn(hourTextBlock, 0);
                consulationMomentsGrid.Children.Add(hourTextBlock);
                hour++;
            }
        }

        private void AddConsultationButton_Click(object sender, RoutedEventArgs e)
        {
            int row = Grid.GetRow((Button)sender);
            int column = Grid.GetColumn((Button)sender);

            DateTime consultationDate = GetConsultationDateTimeForCell(row, column);

            AddConsultationWindow window = new AddConsultationWindow(consultationDate, _doctor, _unitOfWork);
            window.ShowDialog();
        }

        private DateTime GetConsultationDateTimeForCell(int row, int column)
        {
            int dayOfWeek = column;
            int hour = _startHour + (row - 1);
            return _startDate.AddDays(dayOfWeek - 1).AddHours(hour);
        }

        private static string GetHourString(int hour)
        {
            return $"{hour.ToString().PadLeft(2, '0')}:00";
        }

    }
    //TODO: also check the TODO's in DoctorsWindow.xaml.cs, DatePickerWindow.xaml.cs, AddConsultationWindow.xaml.cs
}
