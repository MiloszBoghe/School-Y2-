﻿using System;

namespace Consultation.Domain
{
    public class Consult
    {
        public int DoctorId { get; set; }
        public int PatientId { get; set; }
        public DateTime ConsultationDate { get; set; }
        public int Duration { get; set; }
        public string Comment { get; set; }
    }
}
