﻿using System;
using Consultation.Data.Interfaces;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Consultation.Data
{
    public class ConsultationHoursRepository : IConsultationHoursRepository
    {
        IConnectionFactory _connectionFactory;
        public ConsultationHoursRepository(IConnectionFactory factory)
        {
            _connectionFactory = factory;
        }

        public List<string> GetConsultationStartHoursForDoctorOnWeekDay(int doctorId, int weekday)
        {
            //TODO: use ADO.NET to retrieve the consultation hours of a certain doctor on a certain weekday.
            //Use the connectionFactory that is injected into the constructor to create a connection
            //Use parameters to pass the input data
            //Return the 'Start' column of each matching ConsultationHour row
            SqlDataReader reader = null;
            List<string> startHoursList = new List<string>();
            SqlConnection connection = _connectionFactory.CreateSqlConnection();

            string selectStatement =
                "SELECT start " +
                "FROM ConsultationHours " +
                "WHERE DoctorId = @dId and DayNumber = @wd";

            //command maken en parameters instellen:
            SqlCommand selectCommand = new SqlCommand();
            selectCommand.Connection = connection;
            selectCommand.Parameters.AddWithValue("@dId", doctorId);
            selectCommand.Parameters.AddWithValue("@wd", weekday);
            selectCommand.CommandText = selectStatement;
            try
            {
                connection.Open();
                reader = selectCommand.ExecuteReader();

                while (reader.Read())
                {
                    string hour = Convert.ToString(reader["start"]);
                    startHoursList.Add(hour);
                }
            }

            finally
            {
                reader?.Close();
                connection?.Close();
            }
            return startHoursList;
        }
    }

}
