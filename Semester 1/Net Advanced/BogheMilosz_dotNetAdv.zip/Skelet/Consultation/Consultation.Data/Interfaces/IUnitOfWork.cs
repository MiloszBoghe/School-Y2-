﻿namespace Consultation.Data.Interfaces
{
    public interface IUnitOfWork
    {
        IDoctorsRepository DoctorsRepository { get; }
        IPatientsRepository PatientsRepository { get; }
        IConsultationsRepository ConsultationsRepository { get; }
        IConsultationHoursRepository ConsultationHoursRepository { get; }
    }
}