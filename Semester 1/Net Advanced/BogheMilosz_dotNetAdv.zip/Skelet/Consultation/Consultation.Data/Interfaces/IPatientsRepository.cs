﻿using Consultation.Domain;
using System.Collections.Generic;

namespace Consultation.Data.Interfaces
{
    public interface IPatientsRepository
    {
        IList<Patient> GetAllPatients();
    }
}
