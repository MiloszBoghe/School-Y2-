﻿using System.Collections.Generic;

namespace Consultation.Data.Interfaces
{
    public interface IConsultationHoursRepository
    {
        List<string> GetConsultationStartHoursForDoctorOnWeekDay(int doctorId, int weekday);
    }
}
