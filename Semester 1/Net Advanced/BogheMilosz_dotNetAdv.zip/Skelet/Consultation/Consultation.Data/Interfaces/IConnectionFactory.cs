﻿using System.Data.SqlClient;

namespace Consultation.Data.Interfaces
{
    public interface IConnectionFactory
    {   
        SqlConnection CreateSqlConnection();
    }
}
