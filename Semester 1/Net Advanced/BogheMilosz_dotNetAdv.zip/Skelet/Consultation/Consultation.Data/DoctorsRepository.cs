﻿using Consultation.Data.Interfaces;
using Consultation.Domain;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Consultation.Data
{
    public class DoctorsRepository : IDoctorsRepository
    {
        IConnectionFactory _connectionFactory;
        public DoctorsRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        public IList<Doctor> GetAllDoctors()
        {
            //DONE: use ADO.NET to retrieve all doctors.
            //Use the connectionFactory that is injected into the constructor to create a connection
            //This method should be as efficient as possible (there could be many doctors in the database)
            SqlDataReader reader = null;
            List<Doctor> doctorList = new List<Doctor>();
            SqlConnection connection = _connectionFactory.CreateSqlConnection();

            string selectStatement =
                "SELECT * " +
                "FROM Doctors";
                
            SqlCommand command = new SqlCommand(selectStatement,connection);
            try
            {
                connection.Open();
                reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Doctor doctor = new Doctor()
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Name = Convert.ToString(reader["Name"]),
                        FirstName = Convert.ToString(reader["FirstName"]),
                        Specialism = Convert.ToString(reader["Specialism"])
                    };
                    doctorList.Add(doctor);
                }
            }
            catch (Exception)
            {
                Console.WriteLine("something went wrong");
            }

            finally
            {
                reader?.Close();
                connection?.Close();
            }

            return doctorList;

        }
    }
}
