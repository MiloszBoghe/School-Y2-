﻿using Consultation.Data.Interfaces;

namespace Consultation.Data
{
    /// <summary>
    /// Container that holds a reference to the different repositories
    /// </summary>
    public class UnitOfWork : IUnitOfWork
    {
        public IDoctorsRepository DoctorsRepository { get; }
        public IPatientsRepository PatientsRepository { get; }
        public IConsultationsRepository ConsultationsRepository { get; }
        public IConsultationHoursRepository ConsultationHoursRepository { get; }

        public UnitOfWork(IConnectionFactory connectionFactory)
        {
            DoctorsRepository = new DoctorsRepository(connectionFactory);
            PatientsRepository = new PatientsRepository(connectionFactory);
            ConsultationsRepository = new ConsultationsRepository(connectionFactory);
            ConsultationHoursRepository = new ConsultationHoursRepository(connectionFactory);
        }
    }
}