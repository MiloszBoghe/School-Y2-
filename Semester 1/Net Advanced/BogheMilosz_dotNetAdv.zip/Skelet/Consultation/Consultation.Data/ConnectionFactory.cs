﻿using System;
using Consultation.Data.Interfaces;
using System.Data.SqlClient;
using System.Configuration;

namespace Consultation.Data
{
    public class ConnectionFactory : IConnectionFactory
    {
        public SqlConnection CreateSqlConnection()
        {
            //DONE: run the script "CreateConsultationsDb.sql" to create the database
            //DONE: create and return a SqlConnection that uses the connectionstring in the config file

            string connectionString = ConfigurationManager.ConnectionStrings["ConsultationsConnection"].ConnectionString;
            return new SqlConnection(connectionString);
        }
    }
}
