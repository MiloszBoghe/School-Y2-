/* Check if database already exists and delete it if it does exist*/
IF EXISTS(SELECT 1 FROM master.dbo.sysdatabases WHERE name = 'Consultations') 
BEGIN
DROP DATABASE Consultations
END
GO

CREATE DATABASE Consultations
GO

USE Consultations
GO

/****** Object:  Table [dbo].[ConsultationHours]   ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ConsultationHours](
	[DoctorId] [int] NOT NULL,
	[DayNumber] [nvarchar](50) NOT NULL,
	[Start] [nvarchar](50) NOT NULL,
	[Duration] [int] NULL,
 CONSTRAINT [PK_ConsultationHours] PRIMARY KEY CLUSTERED 
(
	[DoctorId] ASC,
	[DayNumber] ASC,
	[Start] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Consultations]   ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Consultations](
	[DoctorId] [int] NOT NULL,
	[PatientId] [int] NOT NULL,
	[ConsultationDate] [datetime] NOT NULL,
	[Duration] [int] NOT NULL,
	[Comment] [nvarchar](max) NULL,
 CONSTRAINT [PK_Consultations] PRIMARY KEY CLUSTERED 
(
	[DoctorId] ASC,
	[PatientId] ASC,
	[ConsultationDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Doctors]  ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Doctors](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[FirstName] [nvarchar](50) NOT NULL,
	[Specialism] [nvarchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[Patients]  ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Patients](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[FirstName] [nvarchar](50) NOT NULL,
	[DateOfBirth] [date] NOT NULL,
	[Sex] [char](1) NOT NULL,
	[Address1] [nvarchar](100) NOT NULL,
	[Zip] [int] NOT NULL,
	[City] [nvarchar](25) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (1, N'1', N'09:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (1, N'1', N'13:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (1, N'4', N'09:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (1, N'5', N'13:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (2, N'2', N'13:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (2, N'3', N'09:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (2, N'5', N'09:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (3, N'3', N'09:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (3, N'3', N'13:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (4, N'1', N'13:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (4, N'2', N'09:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (4, N'2', N'13:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (5, N'5', N'09:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (5, N'5', N'13:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (6, N'1', N'09:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (6, N'2', N'09:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (6, N'3', N'09:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (6, N'4', N'09:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (6, N'5', N'09:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (7, N'1', N'13:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (7, N'2', N'13:00', 60)
INSERT [dbo].[ConsultationHours] ([DoctorId], [DayNumber], [Start], [Duration]) VALUES (7, N'3', N'13:00', 60)
INSERT [dbo].[Consultations] ([DoctorId], [PatientId], [ConsultationDate], [Duration], [Comment]) VALUES (1, 1, CAST(N'2020-01-13T09:00:00.000' AS DateTime), 60, N'Some comment')
INSERT [dbo].[Consultations] ([DoctorId], [PatientId], [ConsultationDate], [Duration], [Comment]) VALUES (1, 1, CAST(N'2020-01-13T13:00:00.000' AS DateTime), 60, null)
INSERT [dbo].[Consultations] ([DoctorId], [PatientId], [ConsultationDate], [Duration], [Comment]) VALUES (1, 2, CAST(N'2020-01-14T13:00:00.000' AS DateTime), 60, N'Some comment')

SET IDENTITY_INSERT [dbo].[Doctors] ON 
INSERT [dbo].[Doctors] ([Id], [Name], [FirstName], [Specialism]) VALUES (1, N'Arts', N'Dirk', N'Maag- en darmziekten')
INSERT [dbo].[Doctors] ([Id], [Name], [FirstName], [Specialism]) VALUES (2, N'Coppens', N'Peter', N'Anesthesie')
INSERT [dbo].[Doctors] ([Id], [Name], [FirstName], [Specialism]) VALUES (3, N'Dewilde', N'Koen', N'Cardiologie')
INSERT [dbo].[Doctors] ([Id], [Name], [FirstName], [Specialism]) VALUES (4, N'Bolla', N'Lieve', N'Gastro-enterologie')
INSERT [dbo].[Doctors] ([Id], [Name], [FirstName], [Specialism]) VALUES (5, N'Beckers', N'Petra', N'Hematologie')
INSERT [dbo].[Doctors] ([Id], [Name], [FirstName], [Specialism]) VALUES (6, N'De Vleeschouwer', N'Anja', N'Neurochirurgie')
INSERT [dbo].[Doctors] ([Id], [Name], [FirstName], [Specialism]) VALUES (7, N'Buyse', N'Steven', N'Pneumologie')
SET IDENTITY_INSERT [dbo].[Doctors] OFF

SET IDENTITY_INSERT [dbo].[Patients] ON 
INSERT [dbo].[Patients] ([Id], [Name], [FirstName], [DateOfBirth], [Sex], [Address1], [Zip], [City]) VALUES (1, N'Peters', N'Jan', CAST(N'1965-12-10' AS Date), N'M', N'Beemdstraat 1', 3500, N'Hasselt')
INSERT [dbo].[Patients] ([Id], [Name], [FirstName], [DateOfBirth], [Sex], [Address1], [Zip], [City]) VALUES (2, N'Janssens', N'Freek', CAST(N'1980-03-01' AS Date), N'M', N'Kerkstraat 97', 3600, N'Genk')
INSERT [dbo].[Patients] ([Id], [Name], [FirstName], [DateOfBirth], [Sex], [Address1], [Zip], [City]) VALUES (3, N'Adriaensens', N'Annie', CAST(N'1960-05-15' AS Date), N'V', N'Overweg 2', 3700, N'Tongeren')
SET IDENTITY_INSERT [dbo].[Patients] OFF