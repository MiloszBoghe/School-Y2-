<?php
//Milosz Boghe
namespace Models;

use Exception;

class ModelException extends Exception
{
}
