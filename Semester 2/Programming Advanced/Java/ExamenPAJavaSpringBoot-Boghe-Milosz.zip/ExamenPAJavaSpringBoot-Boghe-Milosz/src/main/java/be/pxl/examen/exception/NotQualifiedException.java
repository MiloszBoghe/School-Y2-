package be.pxl.examen.exception;

public class NotQualifiedException extends Exception {

	public NotQualifiedException(String message) {
		super(message);
	}
}
