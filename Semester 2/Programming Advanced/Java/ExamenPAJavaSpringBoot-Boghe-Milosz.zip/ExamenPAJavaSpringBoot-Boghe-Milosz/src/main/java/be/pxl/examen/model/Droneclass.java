package be.pxl.examen.model;

public enum Droneclass {
	C0,
	C1,
	C2;
}
