package be.pxl.examen.exception;

public class DroneUnavailableException extends Exception {

	public DroneUnavailableException(String message) {
		super(message);
	}
}
