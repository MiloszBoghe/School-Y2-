INSERT INTO drone (code, description, weight) VALUES
	('DRONE_1', 'DJI Phantom 4 Pro', 4035),
  ('DRONE_2', 'DJI Inspire 2', 12000),
  ('DRONE_3', 'DJI Mavic Mini Fly ', 185);


INSERT INTO dronepilot(email, droneclass) VALUES
  ('mark.camps@pxl.be', 'C2'),
  ('peter.goris@drones.eu', 'C0'),
  ('griet.jacobs@testdrone.be', 'C2');
