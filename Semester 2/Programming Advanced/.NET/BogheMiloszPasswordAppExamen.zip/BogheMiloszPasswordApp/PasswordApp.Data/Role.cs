﻿using System;
using Microsoft.AspNetCore.Identity;

namespace PasswordApp.Data
{
    public class Role : IdentityRole<Guid>
    {

    }
}