﻿namespace PasswordApp.Web.Services
{
    public class EncryptionSettings
    {
        public string SecretKey { get; set; }
    }
}