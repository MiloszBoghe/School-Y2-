﻿using System;

namespace PasswordApp.Web.Models
{
    public class EntryListItemViewModel
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string UserName { get; set; }
    }
}